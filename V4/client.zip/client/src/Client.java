import java.io.*;
import java.net.*;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;


public class Client {

  public final static int SOCKET_PORT = 8888;//5000;      // you may change this
  public final static int SOCKET_PORT2 = 5000;
  public final static String SERVER = "localhost";  // localhost
  public final static String
  FILE_TO_RECEIVED = "/home/yonattan/Documentos/Recieve/TheTrooper.mp3";  
  private static Socket socket;
  public final static String
  TXT_TO_RECEIVED = "/home/yonattan/Documentos/Operativos/V2/client/Recieve/songslist.txt"; 
                                                                                    

  public final static int FILE_SIZE = 106484564; // file size temporary hard coded
  

  public static void main (String [] args ) throws IOException, Exception {
      
      
    //recieveTxt();
    //sendMessage("Hola");
    //recieveFIle();
    //recieveTxt();
    //readFile();

  }
  
  
  
    
  
  // Este metodo lee un archivo linea por linea y almacena su contenido en un arrayList
  

  
  
  
  
  // Este metodo recibe el stream de un cliente al cual se conecta por sockets.
  
    private static void recieveFIle() throws IOException {
        int bytesRead;
        int current = 0;
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        Socket sock = null;
        try {
        sock = new Socket(SERVER, SOCKET_PORT2);
        System.out.println("Conectando...");

        

        // receive file
        byte [] mybytearray  = new byte [FILE_SIZE];
        InputStream is = sock.getInputStream();
        fos = new FileOutputStream(FILE_TO_RECEIVED);
        bos = new BufferedOutputStream(fos);
        bytesRead = is.read(mybytearray,0,mybytearray.length);
        current = bytesRead;
        

        do {
           bytesRead = is.read(mybytearray, current, (mybytearray.length-current));
           if(bytesRead >= 0) current += bytesRead;
           System.out.println("Archivo " + FILE_TO_RECEIVED
            + " Descargando (" + current + " bytes leidos)");
        } while(bytesRead > -1);

        bos.write(mybytearray, 0 , current);
        bos.flush();


      }
      finally {
        if (fos != null) fos.close();
        if (bos != null) bos.close();
        if (sock != null) sock.close();
      }
      }
    
    
    
    
    
    // RECIEVE JUST THE TXT
    
    private static void recieveTxt() throws IOException {
        int bytesRead;
        int current = 0;
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        Socket sock = null;
        try {
        sock = new Socket(SERVER, SOCKET_PORT2);
        System.out.println("Conectando...");

        

        // receive file
        byte [] mybytearray  = new byte [FILE_SIZE];
        InputStream is = sock.getInputStream();
        fos = new FileOutputStream(TXT_TO_RECEIVED);
        bos = new BufferedOutputStream(fos);
        bytesRead = is.read(mybytearray,0,mybytearray.length);
        current = bytesRead;


        do {
           bytesRead =
              is.read(mybytearray, current, (mybytearray.length-current));
           if(bytesRead >= 0) current += bytesRead;
           System.out.println("Archivo " + TXT_TO_RECEIVED
            + " Descargando (" + current + " bytes leidos)");
        } while(bytesRead > -1);

        bos.write(mybytearray, 0 , current);
        bos.flush();


      }
      finally {
        if (fos != null) fos.close();
        if (bos != null) bos.close();
        if (sock != null) sock.close();
      }
      }

}
